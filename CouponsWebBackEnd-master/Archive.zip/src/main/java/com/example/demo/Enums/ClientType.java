package com.example.demo.Enums;

public enum ClientType {
    Administrator, Company, Customer;
}
