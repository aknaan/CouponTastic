package com.example.demo.Exceptions;

public class LoginErrorException extends Exception{
    public LoginErrorException(String message) {
        super("");
    }
}