package com.example.demo.Exceptions;

public class CompanyExistsException extends Exception {
    public CompanyExistsException(String message) {
        super(message);
    }
}

