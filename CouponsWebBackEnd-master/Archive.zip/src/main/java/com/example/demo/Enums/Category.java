package com.example.demo.Enums;

public enum Category {
    SPORT,TOURISM,SPA,KIDS,SHOWS,FOOD,BEVERAGES,ELECTRONICS
}
