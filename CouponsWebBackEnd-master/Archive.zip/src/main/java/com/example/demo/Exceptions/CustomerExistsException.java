package com.example.demo.Exceptions;

public class CustomerExistsException extends Exception {
    public CustomerExistsException(String message) {
        super(message);
    }
}
